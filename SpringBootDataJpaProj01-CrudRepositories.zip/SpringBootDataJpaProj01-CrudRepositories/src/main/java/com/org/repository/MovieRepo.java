package com.org.repository;

import org.springframework.data.repository.CrudRepository;

import com.org.entity.Movie;

//public interface MovieRepo extends CrudRepository<Movie, Integer> {
//
//}

public interface MovieRepo extends CrudRepository<Movie, Integer> {

}
