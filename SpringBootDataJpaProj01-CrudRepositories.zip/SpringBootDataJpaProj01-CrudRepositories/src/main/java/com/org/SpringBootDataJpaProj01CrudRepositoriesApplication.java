package com.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDataJpaProj01CrudRepositoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpaProj01CrudRepositoriesApplication.class, args);
	}

}
